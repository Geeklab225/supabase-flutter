import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { CreditCard, MapPin, Phone, User, Mail, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/components/ui/use-toast';
import Header from '@/components/Header';

const CheckoutPage = () => {
  const navigate = useNavigate();
  const { items, getTotalPrice, clearCart, setDeliveryInfo } = useCart();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    paymentMethod: ''
  });

  const [isProcessing, setIsProcessing] = useState(false);

  const cities = [
    { name: 'Abengourou', fee: 1500 },
    { name: 'Abidjan', fee: 2000 },
    { name: 'Bouaké', fee: 3000 },
    { name: 'Daloa', fee: 3500 },
    { name: 'Yamoussoukro', fee: 2500 },
    { name: 'San-Pédro', fee: 4000 },
    { name: 'Korhogo', fee: 4500 },
    { name: 'Man', fee: 4000 },
    { name: 'Divo', fee: 3000 },
    { name: 'Gagnoa', fee: 3500 }
  ];

  const paymentMethods = [
    { id: 'orange_money', name: 'Orange Money' },
    { id: 'mtn_money', name: 'MTN Mobile Money' },
    { id: 'moov_money', name: 'Moov Money' },
    { id: 'wave', name: 'Wave' },
    { id: 'cash', name: 'Paiement à la livraison' }
  ];

  const selectedCity = cities.find(city => city.name === formData.city);
  const deliveryFee = selectedCity ? selectedCity.fee : 0;
  const subtotal = getTotalPrice();
  const total = subtotal + deliveryFee;

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const generateOrderId = () => {
    return 'CI' + Date.now().toString().slice(-8) + Math.random().toString(36).substr(2, 4).toUpperCase();
  };

  const generateDeliveryAgent = () => {
    const agents = [
      { name: 'Kouassi Jean', phone: '+225 07 12 34 56 78' },
      { name: 'Adjoua Marie', phone: '+225 05 98 76 54 32' },
      { name: 'Yao Pierre', phone: '+225 01 23 45 67 89' },
      { name: 'Akissi Fatou', phone: '+225 09 87 65 43 21' },
      { name: 'Koffi Michel', phone: '+225 06 54 32 10 98' }
    ];
    return agents[Math.floor(Math.random() * agents.length)];
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.phone || 
        !formData.address || !formData.city || !formData.paymentMethod) {
      toast({
        title: "Informations manquantes",
        description: "Veuillez remplir tous les champs obligatoires.",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);

    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      const orderId = generateOrderId();
      const deliveryAgent = generateDeliveryAgent();
      
      const orderData = {
        orderId,
        items,
        customer: formData,
        deliveryFee,
        subtotal,
        total,
        deliveryAgent,
        orderDate: new Date().toISOString(),
        estimatedDelivery: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString() // 2 hours from now
      };

      // Save order to localStorage
      const existingOrders = JSON.parse(localStorage.getItem('courssier-orders') || '[]');
      existingOrders.push(orderData);
      localStorage.setItem('courssier-orders', JSON.stringify(existingOrders));

      // Set delivery info and clear cart
      setDeliveryInfo({
        city: formData.city,
        address: formData.address,
        deliveryFee
      });
      
      clearCart();

      toast({
        title: "Commande confirmée !",
        description: `Votre commande ${orderId} a été enregistrée avec succès.`
      });

      navigate(`/receipt/${orderId}`);
    } catch (error) {
      toast({
        title: "Erreur de traitement",
        description: "Une erreur est survenue lors du traitement de votre commande.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  if (items.length === 0) {
    navigate('/cart');
    return null;
  }

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>COURSSIER IVOIR - Finaliser ma commande</title>
        <meta name="description" content="Finalisez votre commande et procédez au paiement" />
      </Helmet>
      
      <Header />

      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <div className="flex items-center space-x-4 mb-6">
            <Button
              variant="ghost"
              onClick={() => navigate('/cart')}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour au panier
            </Button>
          </div>
          
          <h1 className="text-3xl font-bold text-white mb-2">Finaliser ma commande</h1>
          <p className="text-white/80">Remplissez vos informations pour procéder au paiement</p>
        </motion.div>

        <form onSubmit={handleSubmit}>
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Customer Information */}
            <div className="lg:col-span-2 space-y-6">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <Card className="glass-effect border-white/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <User className="w-5 h-5 mr-2" />
                      Informations personnelles
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-white/80 text-sm font-medium mb-2">
                          Prénom *
                        </label>
                        <Input
                          value={formData.firstName}
                          onChange={(e) => handleInputChange('firstName', e.target.value)}
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/60"
                          placeholder="Votre prénom"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-white/80 text-sm font-medium mb-2">
                          Nom *
                        </label>
                        <Input
                          value={formData.lastName}
                          onChange={(e) => handleInputChange('lastName', e.target.value)}
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/60"
                          placeholder="Votre nom"
                          required
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-white/80 text-sm font-medium mb-2">
                        Email *
                      </label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 w-5 h-5" />
                        <Input
                          type="email"
                          value={formData.email}
                          onChange={(e) => handleInputChange('email', e.target.value)}
                          className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/60"
                          placeholder="contact@courssierivoir.com"
                          required
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-white/80 text-sm font-medium mb-2">
                        Téléphone *
                      </label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 w-5 h-5" />
                        <Input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => handleInputChange('phone', e.target.value)}
                          className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/60"
                          placeholder="0719550919"
                          required
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <Card className="glass-effect border-white/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <MapPin className="w-5 h-5 mr-2" />
                      Adresse de livraison
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="block text-white/80 text-sm font-medium mb-2">
                        Ville *
                      </label>
                      <Select value={formData.city} onValueChange={(value) => handleInputChange('city', value)}>
                        <SelectTrigger className="bg-white/10 border-white/20 text-white">
                          <SelectValue placeholder="Sélectionnez votre ville" />
                        </SelectTrigger>
                        <SelectContent>
                          {cities.map((city) => (
                            <SelectItem key={city.name} value={city.name}>
                              {city.name} - {city.fee.toLocaleString()} FCFA
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="block text-white/80 text-sm font-medium mb-2">
                        Adresse complète *
                      </label>
                      <Input
                        value={formData.address}
                        onChange={(e) => handleInputChange('address', e.target.value)}
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/60"
                        placeholder="Quartier, rue, numéro, point de repère..."
                        required
                      />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                <Card className="glass-effect border-white/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <CreditCard className="w-5 h-5 mr-2" />
                      Mode de paiement
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Select value={formData.paymentMethod} onValueChange={(value) => handleInputChange('paymentMethod', value)}>
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue placeholder="Choisissez votre mode de paiement" />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentMethods.map((method) => (
                          <SelectItem key={method.id} value={method.id}>
                            {method.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* Order Summary */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <Card className="glass-effect border-white/20 sticky top-24">
                <CardHeader>
                  <CardTitle className="text-white">Récapitulatif</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    {items.map((item) => (
                      <div key={item.id} className="flex justify-between text-sm">
                        <span className="text-white/80">
                          {item.name} x{item.quantity}
                        </span>
                        <span className="text-white">
                          {(item.price * item.quantity).toLocaleString()} FCFA
                        </span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="border-t border-white/20 pt-4 space-y-2">
                    <div className="flex justify-between text-white/80">
                      <span>Sous-total</span>
                      <span>{subtotal.toLocaleString()} FCFA</span>
                    </div>
                    
                    <div className="flex justify-between text-white/80">
                      <span>Frais de livraison</span>
                      <span>
                        {deliveryFee > 0 ? `${deliveryFee.toLocaleString()} FCFA` : 'Sélectionnez une ville'}
                      </span>
                    </div>
                    
                    <div className="flex justify-between text-xl font-bold text-white border-t border-white/20 pt-2">
                      <span>Total</span>
                      <span className="text-orange-400">{total.toLocaleString()} FCFA</span>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={isProcessing}
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3 text-lg"
                  >
                    {isProcessing ? (
                      <div className="flex items-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Traitement en cours...
                      </div>
                    ) : (
                      <>
                        <CreditCard className="w-5 h-5 mr-2" />
                        Confirmer la commande
                      </>
                    )}
                  </Button>

                  <p className="text-xs text-white/60 text-center">
                    En confirmant votre commande, vous acceptez nos conditions de vente.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CheckoutPage;