
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/components/ui/use-toast';
import Header from '@/components/Header';

const CartPage = () => {
  const { items, updateQuantity, removeFromCart, getTotalPrice, getTotalItems } = useCart();
  const { toast } = useToast();

  const handleQuantityChange = (productId, newQuantity) => {
    if (newQuantity < 1) {
      removeFromCart(productId);
      toast({
        title: "Produit retiré",
        description: "Le produit a été retiré de votre panier."
      });
    } else {
      updateQuantity(productId, newQuantity);
    }
  };

  const handleRemoveItem = (productId, productName) => {
    removeFromCart(productId);
    toast({
      title: "Produit retiré",
      description: `${productName} a été retiré de votre panier.`
    });
  };

  const totalPrice = getTotalPrice();
  const totalItems = getTotalItems();

  if (items.length === 0) {
    return (
      <div className="min-h-screen">
        <Helmet>
          <title>COURSSIER IVOIR - Panier</title>
          <meta name="description" content="Votre panier d'achat COURSSIER IVOIR" />
        </Helmet>
        
        <Header />

        <div className="container mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-md mx-auto"
          >
            <div className="glass-effect rounded-lg p-12 border border-white/20">
              <ShoppingBag className="w-24 h-24 text-white/40 mx-auto mb-6" />
              <h2 className="text-2xl font-bold text-white mb-4">Votre panier est vide</h2>
              <p className="text-white/80 mb-8">
                Découvrez nos produits frais et ajoutez-les à votre panier pour commencer vos achats.
              </p>
              <Link to="/products">
                <Button className="bg-orange-500 hover:bg-orange-600 text-white">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Continuer mes achats
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>COURSSIER IVOIR - Mon Panier ({totalItems} articles)</title>
        <meta name="description" content="Consultez et modifiez votre panier d'achat COURSSIER IVOIR" />
      </Helmet>
      
      <Header />

      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-white">Mon Panier</h1>
              <p className="text-white/80">{totalItems} article{totalItems > 1 ? 's' : ''} dans votre panier</p>
            </div>
            <Link to="/products">
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Continuer mes achats
              </Button>
            </Link>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="glass-effect border-white/20">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                        <img  
                          alt={`${item.name} - ${item.description}`}
                          className="w-full h-full object-cover"
                         src="https://images.unsplash.com/photo-1539277036182-29704888f8a9" />
                      </div>

                      <div className="flex-1 min-w-0">
                        <h3 className="text-lg font-semibold text-white truncate">{item.name}</h3>
                        <p className="text-white/60 text-sm truncate">{item.description}</p>
                        <div className="flex items-center mt-2">
                          <span className="text-orange-400 font-bold">
                            {item.price.toLocaleString()} FCFA
                          </span>
                          <span className="text-white/60 text-sm ml-1">/{item.unit}</span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3">
                        <div className="flex items-center space-x-2 bg-white/10 rounded-lg p-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                            className="h-8 w-8 p-0 text-white hover:bg-white/20"
                          >
                            <Minus className="w-4 h-4" />
                          </Button>
                          
                          <span className="text-white font-medium min-w-[2rem] text-center">
                            {item.quantity}
                          </span>
                          
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                            className="h-8 w-8 p-0 text-white hover:bg-white/20"
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                        </div>

                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleRemoveItem(item.id, item.name)}
                          className="h-8 w-8 p-0 text-red-400 hover:bg-red-500/20"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="flex justify-between items-center mt-4 pt-4 border-t border-white/20">
                      <span className="text-white/80">Sous-total:</span>
                      <span className="text-xl font-bold text-white">
                        {(item.price * item.quantity).toLocaleString()} FCFA
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <Card className="glass-effect border-white/20 sticky top-24">
              <CardHeader>
                <CardTitle className="text-white">Résumé de la commande</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between text-white/80">
                  <span>Sous-total ({totalItems} articles)</span>
                  <span>{totalPrice.toLocaleString()} FCFA</span>
                </div>
                
                <div className="flex justify-between text-white/80">
                  <span>Frais de livraison</span>
                  <span className="text-green-400">Calculés à l'étape suivante</span>
                </div>
                
                <div className="border-t border-white/20 pt-4">
                  <div className="flex justify-between text-xl font-bold text-white">
                    <span>Total estimé</span>
                    <span className="text-orange-400">{totalPrice.toLocaleString()} FCFA</span>
                  </div>
                  <p className="text-xs text-white/60 mt-1">+ frais de livraison</p>
                </div>

                <Link to="/checkout" className="block">
                  <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3 text-lg">
                    Procéder au paiement
                  </Button>
                </Link>

                <div className="text-center">
                  <Link to="/products">
                    <Button variant="ghost" className="text-white/80 hover:text-white hover:bg-white/10">
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Continuer mes achats
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
