
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Plus, Search, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/contexts/CartContext';
import { useToast } from '@/components/ui/use-toast';
import Header from '@/components/Header';

const ProductsPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const { addToCart } = useCart();
  const { toast } = useToast();

  const categories = [
    { id: 'all', name: 'Tous les produits' },
    { id: 'legumes', name: 'Légumes' },
    { id: 'fruits', name: 'Fruits' },
    { id: 'cereales', name: 'Céréales' },
    { id: 'tubercules', name: 'Tubercules' },
    { id: 'epices', name: 'Épices' }
  ];

  const products = [
    {
      id: 1,
      name: 'Tomates Fraîches',
      category: 'legumes',
      price: 1500,
      unit: 'kg',
      description: 'Tomates fraîches et juteuses, parfaites pour vos sauces',
      inStock: true,
      popular: true
    },
    {
      id: 2,
      name: 'Bananes Plantains',
      category: 'fruits',
      price: 1000,
      unit: 'régime',
      description: 'Bananes plantains mûres, idéales pour l\'attiéké',
      inStock: true,
      popular: true
    },
    {
      id: 3,
      name: 'Riz Local',
      category: 'cereales',
      price: 2500,
      unit: 'kg',
      description: 'Riz local de qualité supérieure, grain long',
      inStock: true,
      popular: false
    },
    {
      id: 4,
      name: 'Ignames',
      category: 'tubercules',
      price: 2000,
      unit: 'kg',
      description: 'Ignames fraîches, parfaites pour le foutou',
      inStock: true,
      popular: true
    },
    {
      id: 5,
      name: 'Piment Rouge',
      category: 'epices',
      price: 500,
      unit: '100g',
      description: 'Piment rouge séché, très piquant',
      inStock: true,
      popular: false
    },
    {
      id: 6,
      name: 'Aubergines',
      category: 'legumes',
      price: 1200,
      unit: 'kg',
      description: 'Aubergines violettes fraîches et tendres',
      inStock: true,
      popular: false
    },
    {
      id: 7,
      name: 'Mangues',
      category: 'fruits',
      price: 800,
      unit: 'kg',
      description: 'Mangues sucrées et parfumées de saison',
      inStock: false,
      popular: true
    },
    {
      id: 8,
      name: 'Maïs',
      category: 'cereales',
      price: 1800,
      unit: 'kg',
      description: 'Maïs jaune sec, idéal pour l\'attiéké',
      inStock: true,
      popular: false
    },
    {
      id: 9,
      name: 'Manioc',
      category: 'tubercules',
      price: 1500,
      unit: 'kg',
      description: 'Manioc frais, base de l\'attiéké traditionnel',
      inStock: true,
      popular: true
    },
    {
      id: 10,
      name: 'Gingembre',
      category: 'epices',
      price: 3000,
      unit: 'kg',
      description: 'Gingembre frais, excellent pour la santé',
      inStock: true,
      popular: false
    },
    {
      id: 11,
      name: 'Oignons',
      category: 'legumes',
      price: 1300,
      unit: 'kg',
      description: 'Oignons jaunes de qualité, base de la cuisine',
      inStock: true,
      popular: true
    },
    {
      id: 12,
      name: 'Ananas',
      category: 'fruits',
      price: 1500,
      unit: 'pièce',
      description: 'Ananas sucré et juteux, cultivé localement',
      inStock: true,
      popular: true
    }
  ];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleAddToCart = (product) => {
    if (!product.inStock) {
      toast({
        title: "Produit indisponible",
        description: "Ce produit n'est pas disponible actuellement.",
        variant: "destructive"
      });
      return;
    }

    addToCart(product);
    toast({
      title: "Ajouté au panier !",
      description: `${product.name} a été ajouté à votre panier.`
    });
  };

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>COURSSIER IVOIR - Nos Produits</title>
        <meta name="description" content="Découvrez notre large sélection de produits vivriers frais : légumes, fruits, céréales, tubercules et épices." />
      </Helmet>
      
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-white mb-4">Nos Produits Vivriers</h1>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Découvrez notre sélection de produits frais et de qualité, cultivés localement en Côte d'Ivoire
          </p>
        </motion.div>

        {/* Search and Filter */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="glass-effect rounded-lg p-6 mb-8 border border-white/20"
        >
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 w-5 h-5" />
              <Input
                placeholder="Rechercher un produit..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/60"
              />
            </div>
            
            <div className="flex gap-2 flex-wrap">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`${
                    selectedCategory === category.id
                      ? 'bg-orange-500 hover:bg-orange-600 text-white'
                      : 'bg-white/10 border-white/20 text-white hover:bg-white/20'
                  }`}
                >
                  <Filter className="w-4 h-4 mr-2" />
                  {category.name}
                </Button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className={`glass-effect border-white/20 card-hover h-full ${!product.inStock ? 'opacity-60' : ''}`}>
                <div className="relative">
                  <img  
                    alt={`${product.name} - ${product.description}`}
                    className="w-full h-48 object-cover rounded-t-lg"
                   src="https://images.unsplash.com/photo-1473766417143-9b5dfbaf8c5b" />
                  
                  <div className="absolute top-2 left-2 flex gap-2">
                    {product.popular && (
                      <Badge className="bg-orange-500 text-white">
                        Populaire
                      </Badge>
                    )}
                    {!product.inStock && (
                      <Badge variant="destructive">
                        Rupture
                      </Badge>
                    )}
                  </div>
                </div>

                <CardContent className="p-4 flex-1">
                  <h3 className="text-lg font-semibold text-white mb-2">{product.name}</h3>
                  <p className="text-white/80 text-sm mb-3 line-clamp-2">{product.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-2xl font-bold text-orange-400">
                        {product.price.toLocaleString()} FCFA
                      </span>
                      <span className="text-white/60 text-sm ml-1">/{product.unit}</span>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="p-4 pt-0">
                  <Button
                    onClick={() => handleAddToCart(product)}
                    disabled={!product.inStock}
                    className={`w-full ${
                      product.inStock
                        ? 'bg-orange-500 hover:bg-orange-600 text-white'
                        : 'bg-gray-500 cursor-not-allowed'
                    }`}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    {product.inStock ? 'Ajouter au panier' : 'Indisponible'}
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <div className="glass-effect rounded-lg p-8 border border-white/20 max-w-md mx-auto">
              <Search className="w-16 h-16 text-white/40 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Aucun produit trouvé</h3>
              <p className="text-white/80">
                Essayez de modifier vos critères de recherche ou de filtrage.
              </p>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default ProductsPage;
