import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { CheckCircle, Download, Phone, MapPin, Clock, Package, ArrowLeft, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import Header from '@/components/Header';

const ReceiptPage = () => {
  const { orderId } = useParams();
  const [order, setOrder] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    const orders = JSON.parse(localStorage.getItem('courssier-orders') || '[]');
    const foundOrder = orders.find(o => o.orderId === orderId);
    
    if (foundOrder) {
      setOrder(foundOrder);
    }
  }, [orderId]);

  const handleDownloadReceipt = () => {
    toast({
      title: "🚧 Cette fonctionnalité n'est pas encore implémentée—mais ne vous inquiétez pas ! Vous pouvez la demander dans votre prochaine demande ! 🚀"
    });
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getPaymentMethodName = (method) => {
    const methods = {
      'orange_money': 'Orange Money',
      'mtn_money': 'MTN Mobile Money',
      'moov_money': 'Moov Money',
      'wave': 'Wave',
      'cash': 'Paiement à la livraison'
    };
    return methods[method] || method;
  };

  if (!order) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="container mx-auto px-4 py-16">
          <div className="text-center max-w-md mx-auto">
            <div className="glass-effect rounded-lg p-12 border border-white/20">
              <Package className="w-24 h-24 text-white/40 mx-auto mb-6" />
              <h2 className="text-2xl font-bold text-white mb-4">Commande introuvable</h2>
              <p className="text-white/80 mb-8">
                La commande demandée n'existe pas ou a été supprimée.
              </p>
              <Link to="/">
                <Button className="bg-orange-500 hover:bg-orange-600 text-white">
                  <Home className="w-4 h-4 mr-2" />
                  Retour à l'accueil
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>COURSSIER IVOIR - Reçu de commande {order.orderId}</title>
        <meta name="description" content={`Reçu de votre commande ${order.orderId} sur COURSSIER IVOIR`} />
      </Helmet>
      
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Success Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-8"
        >
          <div className="glass-effect rounded-lg p-8 border border-white/20 max-w-2xl mx-auto">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <CheckCircle className="w-12 h-12 text-white" />
            </motion.div>
            
            <h1 className="text-3xl font-bold text-white mb-4">Commande Confirmée !</h1>
            <p className="text-xl text-white/80 mb-6">
              Votre commande <span className="text-orange-400 font-bold">{order.orderId}</span> a été enregistrée avec succès.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={handleDownloadReceipt}
                className="bg-orange-500 hover:bg-orange-600 text-white"
              >
                <Download className="w-4 h-4 mr-2" />
                Télécharger le reçu
              </Button>
              <Link to="/">
                <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                  <Home className="w-4 h-4 mr-2" />
                  Retour à l'accueil
                </Button>
              </Link>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Order Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Delivery Information */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="glass-effect border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Phone className="w-5 h-5 mr-2" />
                    Informations de livraison
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-4">
                    <div className="flex items-center mb-3">
                      <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mr-3">
                        <Phone className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h3 className="text-white font-semibold">Votre livreur</h3>
                        <p className="text-green-400 text-sm">Assigné à votre commande</p>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-white/80">Nom:</span>
                        <span className="text-white font-medium">{order.deliveryAgent.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/80">Téléphone:</span>
                        <span className="text-white font-medium">{order.deliveryAgent.phone}</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center text-white/80">
                        <MapPin className="w-4 h-4 mr-2" />
                        <span className="text-sm">Adresse de livraison</span>
                      </div>
                      <p className="text-white font-medium">
                        {order.customer.address}
                      </p>
                      <p className="text-white/80">
                        {order.customer.city}, Côte d'Ivoire
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center text-white/80">
                        <Clock className="w-4 h-4 mr-2" />
                        <span className="text-sm">Livraison estimée</span>
                      </div>
                      <p className="text-white font-medium">
                        {formatDate(order.estimatedDelivery)}
                      </p>
                      <Badge className="bg-orange-500 text-white">
                        Dans 2 heures environ
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Order Items */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Card className="glass-effect border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Package className="w-5 h-5 mr-2" />
                    Articles commandés
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {order.items.map((item) => (
                      <div key={item.id} className="flex items-center space-x-4 p-4 bg-white/5 rounded-lg">
                        <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                          <img  
                            alt={`${item.name} - ${item.description}`}
                            className="w-full h-full object-cover"
                           src="https://images.unsplash.com/photo-1539277036182-29704888f8a9" />
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="text-white font-medium">{item.name}</h3>
                          <p className="text-white/60 text-sm">{item.description}</p>
                          <div className="flex items-center mt-1">
                            <span className="text-orange-400 font-medium">
                              {item.price.toLocaleString()} FCFA
                            </span>
                            <span className="text-white/60 text-sm ml-1">/{item.unit}</span>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className="text-white/80 text-sm">Quantité: {item.quantity}</div>
                          <div className="text-white font-bold">
                            {(item.price * item.quantity).toLocaleString()} FCFA
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <Card className="glass-effect border-white/20 sticky top-24">
              <CardHeader>
                <CardTitle className="text-white">Récapitulatif</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-white/80">
                    <span>Numéro de commande:</span>
                    <span className="text-orange-400 font-bold">{order.orderId}</span>
                  </div>
                  
                  <div className="flex justify-between text-white/80">
                    <span>Date de commande:</span>
                    <span className="text-white">{formatDate(order.orderDate)}</span>
                  </div>
                  
                  <div className="flex justify-between text-white/80">
                    <span>Mode de paiement:</span>
                    <span className="text-white">{getPaymentMethodName(order.customer.paymentMethod)}</span>
                  </div>
                </div>

                <div className="border-t border-white/20 pt-4 space-y-2">
                  <div className="flex justify-between text-white/80">
                    <span>Sous-total:</span>
                    <span>{order.subtotal.toLocaleString()} FCFA</span>
                  </div>
                  
                  <div className="flex justify-between text-white/80">
                    <span>Frais de livraison:</span>
                    <span>{order.deliveryFee.toLocaleString()} FCFA</span>
                  </div>
                  
                  <div className="flex justify-between text-xl font-bold text-white border-t border-white/20 pt-2">
                    <span>Total payé:</span>
                    <span className="text-orange-400">{order.total.toLocaleString()} FCFA</span>
                  </div>
                </div>

                <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-4">
                  <div className="flex items-center mb-2">
                    <CheckCircle className="w-5 h-5 text-green-400 mr-2" />
                    <span className="text-green-400 font-medium">Paiement confirmé</span>
                  </div>
                  <p className="text-white/80 text-sm">
                    Votre paiement a été traité avec succès. Vous recevrez un SMS de confirmation.
                  </p>
                </div>

                <div className="space-y-2">
                  <Link to="/products">
                    <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white">
                      Continuer mes achats
                    </Button>
                  </Link>
                  
                  <Button
                    variant="outline"
                    onClick={handleDownloadReceipt}
                    className="w-full border-white/20 text-white hover:bg-white/10"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Télécharger le reçu
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Back to Home */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center mt-12"
        >
          <Link to="/">
            <Button variant="ghost" className="text-white/80 hover:text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'accueil
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
};

export default ReceiptPage;