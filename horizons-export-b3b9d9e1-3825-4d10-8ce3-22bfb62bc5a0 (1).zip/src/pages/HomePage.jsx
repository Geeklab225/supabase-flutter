import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { ArrowRight, Truck, Clock, Shield, MapPin, Star, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header';

const HomePage = () => {
  const features = [
    {
      icon: Truck,
      title: 'Livraison Rapide',
      description: 'Livraison à domicile dans toute la Côte d\'Ivoire'
    },
    {
      icon: Clock,
      title: 'Service 24/7',
      description: 'Commandez à tout moment, nous sommes toujours là'
    },
    {
      icon: Shield,
      title: 'Paiement Sécurisé',
      description: 'Vos transactions sont protégées et sécurisées'
    }
  ];

  const cities = [
    'Abengourou', 'Abidjan', 'Bouaké', 'Daloa', 'Yamoussoukro', 
    'San-Pédro', 'Korhogo', 'Man', 'Divo', 'Gagnoa'
  ];

  const stats = [
    { icon: Users, value: '10,000+', label: 'Clients Satisfaits' },
    { icon: MapPin, value: '50+', label: 'Villes Couvertes' },
    { icon: Star, value: '4.9/5', label: 'Note Moyenne' }
  ];

  return (
    <div className="min-h-screen">
      <Helmet>
        <title>COURSSIER IVOIR - Accueil</title>
        <meta name="description" content="Bienvenue sur COURSSIER IVOIR, votre plateforme de livraison de produits vivriers en Côte d'Ivoire." />
      </Helmet>
      
      <Header />

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-600/20 to-green-600/20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <div className="space-y-4">
                <h1 className="text-5xl lg:text-6xl font-bold text-white leading-tight">
                  Vos Produits
                  <span className="gradient-text block">Vivriers</span>
                  Livrés à Domicile
                </h1>
                <p className="text-xl text-white/90 max-w-lg">
                  Commandez vos produits vivriers préférés et recevez-les directement chez vous partout en Côte d'Ivoire.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/products">
                  <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 text-lg">
                    Commander Maintenant
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </Link>
                <Button variant="outline" size="lg" className="border-white/30 text-white hover:bg-white/10 px-8 py-4 text-lg">
                  En Savoir Plus
                </Button>
              </div>

              <div className="flex items-center space-x-8">
                {stats.map((stat, index) => {
                  const Icon = stat.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5 + index * 0.1 }}
                      className="text-center"
                    >
                      <Icon className="w-8 h-8 text-orange-400 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-white">{stat.value}</div>
                      <div className="text-sm text-white/80">{stat.label}</div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="relative z-10">
                <img  
                  alt="Produits vivriers frais - légumes, fruits et céréales"
                  className="w-full h-[500px] object-cover rounded-2xl shadow-2xl"
                 src="https://images.unsplash.com/photo-1698491456534-7e2bd61890be" />
              </div>
              <div className="absolute -top-4 -right-4 w-full h-full bg-gradient-to-br from-orange-400/30 to-green-400/30 rounded-2xl"></div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white/5 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-white mb-4">
              Pourquoi Choisir COURSSIER IVOIR ?
            </h2>
            <p className="text-xl text-white/80 max-w-2xl mx-auto">
              Nous offrons le meilleur service de livraison de produits vivriers en Côte d'Ivoire
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.2 }}
                >
                  <Card className="glass-effect border-white/20 card-hover h-full">
                    <CardContent className="p-8 text-center">
                      <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
                      <p className="text-white/80">{feature.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Cities Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-white mb-4">
              Nous Livrons Partout en Côte d'Ivoire
            </h2>
            <p className="text-xl text-white/80 max-w-2xl mx-auto">
              Service de livraison disponible dans toutes les principales villes du pays, en commençant par Abengourou.
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {cities.map((city, index) => (
              <motion.div
                key={city}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="glass-effect border-white/20 rounded-lg p-4 text-center card-hover"
              >
                <MapPin className="w-6 h-6 text-orange-400 mx-auto mb-2" />
                <span className="text-white font-medium">{city}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-orange-600/30 to-green-600/30">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <h2 className="text-4xl font-bold text-white">
              Prêt à Commander ?
            </h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Découvrez notre large sélection de produits vivriers frais et de qualité
            </p>
            <Link to="/products">
              <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-white px-12 py-4 text-lg">
                Voir Nos Produits
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black/20 py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-green-500 rounded-full flex items-center justify-center">
                  <MapPin className="w-4 h-4 text-white" />
                </div>
                <span className="text-white font-bold">COURSSIER IVOIR</span>
              </div>
              <p className="text-white/80 text-sm">
                Votre partenaire de confiance pour la livraison de produits vivriers en Côte d'Ivoire.
              </p>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">Services</h3>
              <div className="space-y-2 text-sm">
                <p className="text-white/80">Livraison à domicile</p>
                <p className="text-white/80">Produits frais</p>
                <p className="text-white/80">Paiement sécurisé</p>
              </div>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">Contact</h3>
              <div className="space-y-2 text-sm">
                <p className="text-white/80">0719550919</p>
                <p className="text-white/80">contact@courssierivoir.com</p>
                <p className="text-white/80">Abengourou, Côte d'Ivoire</p>
              </div>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">Horaires</h3>
              <div className="space-y-2 text-sm">
                <p className="text-white/80">Lun - Dim: 6h - 22h</p>
                <p className="text-white/80">Service client 24/7</p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-white/20 mt-8 pt-8 text-center">
            <p className="text-white/60 text-sm">
              © 2024 COURSSIER IVOIR. Tous droits réservés.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;