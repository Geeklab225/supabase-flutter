
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import HomePage from '@/pages/HomePage';
import ProductsPage from '@/pages/ProductsPage';
import CartPage from '@/pages/CartPage';
import CheckoutPage from '@/pages/CheckoutPage';
import ReceiptPage from '@/pages/ReceiptPage';
import { CartProvider } from '@/contexts/CartContext';

function App() {
  return (
    <CartProvider>
      <Router>
        <div className="min-h-screen">
          <Helmet>
            <title>COURSSIER IVOIR - Livraison de Produits Vivriers en Côte d'Ivoire</title>
            <meta name="description" content="Commandez vos produits vivriers en ligne et recevez-les à domicile partout en Côte d'Ivoire. Service de livraison rapide et fiable." />
          </Helmet>
          
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/products" element={<ProductsPage />} />
            <Route path="/cart" element={<CartPage />} />
            <Route path="/checkout" element={<CheckoutPage />} />
            <Route path="/receipt/:orderId" element={<ReceiptPage />} />
          </Routes>
          
          <Toaster />
        </div>
      </Router>
    </CartProvider>
  );
}

export default App;
