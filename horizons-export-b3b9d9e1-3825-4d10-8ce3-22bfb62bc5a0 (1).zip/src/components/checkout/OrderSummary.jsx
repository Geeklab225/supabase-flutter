import React from 'react';
import { motion } from 'framer-motion';
import { CreditCard } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export const OrderSummary = ({ items, subtotal, deliveryFee, total, isProcessing }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.8, delay: 0.3 }}
    >
      <Card className="glass-effect border-white/20 sticky top-24">
        <CardHeader>
          <CardTitle className="text-white">Récapitulatif</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.id} className="flex justify-between text-sm">
                <span className="text-white/80">
                  {item.name} x{item.quantity}
                </span>
                <span className="text-white">
                  {(item.price * item.quantity).toLocaleString()} FCFA
                </span>
              </div>
            ))}
          </div>
          
          <div className="border-t border-white/20 pt-4 space-y-2">
            <div className="flex justify-between text-white/80">
              <span>Sous-total</span>
              <span>{subtotal.toLocaleString()} FCFA</span>
            </div>
            
            <div className="flex justify-between text-white/80">
              <span>Frais de livraison</span>
              <span>
                {deliveryFee > 0 ? `${deliveryFee.toLocaleString()} FCFA` : 'Sélectionnez une ville'}
              </span>
            </div>
            
            <div className="flex justify-between text-xl font-bold text-white border-t border-white/20 pt-2">
              <span>Total</span>
              <span className="text-orange-400">{total.toLocaleString()} FCFA</span>
            </div>
          </div>

          <Button
            type="submit"
            disabled={isProcessing}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3 text-lg"
          >
            {isProcessing ? (
              <div className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Traitement en cours...
              </div>
            ) : (
              <>
                <CreditCard className="w-5 h-5 mr-2" />
                Confirmer la commande
              </>
            )}
          </Button>

          <p className="text-xs text-white/60 text-center">
            En confirmant votre commande, vous acceptez nos conditions de vente.
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
};